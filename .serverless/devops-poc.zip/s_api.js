
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'martinjj80',
  applicationName: 'devops-poc',
  appUid: 'Pv85sm2St7hvSQ3xwK',
  orgUid: '39f3e9e8-dc2c-4fb0-81ad-7ef9729cb3a0',
  deploymentUid: 'bac9cfb8-926e-45ca-aee7-277e73e36ab6',
  serviceName: 'devops-poc',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'devops-poc-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}